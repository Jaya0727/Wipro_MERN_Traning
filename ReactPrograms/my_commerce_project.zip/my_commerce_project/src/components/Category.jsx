const Category = () => {
  return (
    <section className="py-10 text-center">
      <h2 className="text-3xl font-bold">Man & Woman Fashion</h2>
    </section>
  );
};

export default Category;
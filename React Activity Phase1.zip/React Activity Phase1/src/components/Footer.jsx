const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white text-center py-6 mt-10">
      Thanks for Shopping with Eflyer!
    </footer>
  );
};
export default Footer;
